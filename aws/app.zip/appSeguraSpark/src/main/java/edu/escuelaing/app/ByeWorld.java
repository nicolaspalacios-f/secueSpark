package edu.escuelaing.app;

import static spark.Spark.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class ByeWorld {
    public static void main(String[] args) {
        port(getPort());

        secure("keystores/ecikeystore2.p12", "profeun5", null, null);
        URLReader.loadTrustStore("keystores/ecikeystore.p12");
        get("/bye", (req, res) -> "Bye World");
        get("/remote", (req, res) -> URLReader.readURL("https://localhost:5000/hello"));
    }

    static int getPort() {
        if (System.getenv("PORT") != null) {
            return Integer.parseInt(System.getenv("PORT"));
        }
        return 5001;
    }
}
